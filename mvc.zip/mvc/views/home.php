
<h1>Página Home</h1>
<hr>
Nome: <?php echo $nome; ?></br>
Sobrenome: <?php echo $sobrenome; ?></br>
Idade: <?php echo $idade; ?></br>